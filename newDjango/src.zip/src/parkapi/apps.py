from django.apps import AppConfig


class ParkapiConfig(AppConfig):
    name = 'parkapi'
